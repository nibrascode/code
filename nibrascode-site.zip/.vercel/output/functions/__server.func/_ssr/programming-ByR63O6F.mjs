import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as LibraryIndex } from "./library-page-C381UYqV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/programming-ByR63O6F.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibraryIndex, { section: "programming" });
//#endregion
export { SplitComponent as component };
