var note = document.getElementById("note");
var done = document.getElementById("done");
note.value = localStorage.getItem("nibras-qeyd") || "";
document.getElementById("save").addEventListener("click", function () {
  localStorage.setItem("nibras-qeyd", note.value);
  done.hidden = false;
});
